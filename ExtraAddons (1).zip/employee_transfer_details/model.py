from odoo import api,models,fields

class ContractTransferDetails (models.Model):
    _inherit="hr.contract"
    _name="hr.contract"

    countryOfAccount=fields.Many2one("res.country","Country Of Account")
    transferType=fields.Char()
    otherDetails=fields.Char()
    bank=fields.Char()
    bankBranchName=fields.Char()
    bankSwiftCode=fields.Char()
    bankNo=fields.Char()
    bankAccountCurrency=fields.Char()
    bankAccountHolder=fields.Char()

