{
    'sequence':-10,
    'name':'Employee Transfer Details in contract',
    'author':'Laith Shelleh',
    'depends':['hr_contract'],
    'data':['view.xml'],
}