# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2015 DevIntelle Consulting Service Pvt.Ltd (<http://www.devintellecs.com>).
#
#    For Module Support : devintelle@gmail.com  or Skype : devintelle
#
##############################################################################

{
    'name': 'Employees Payslip Send By Email',
    'version': '13.0.2.0',
    'sequence': 1,
    'category': 'Generic Modules/Human Resources',
    'description':
        """
odoo apps will send Employee Payslip by email to employee
	
	Send Employee Payslip By Email
Odoo Send Employee Payslip By Email
Send payslip by Email
Odoo send payslip by email
Payslip by email
Odoo payslip by email
Employee payslip
Odoo employee payslip
Send employee payslip
Odoo send employee payslip
Employee payslip by email
Odoo employee payslip by email
Employee Payslip Detail Send by Mail 
Odoo Employee Payslip Detail Send by Mail 
Detailed Salary Computation Table is also included in email
Odoo Detailed Salary Computation Table is also included in email
HR payslip send by email
Odoo HR payslip send by Email
Payslip pdf
Odoo payslip pdf
Payslip print in Email
Odoo payslip print in email
Payslip
Odoo payslip

    """,
    'summary': 'odoo apps send Payslip by email to the employee, send Payslip By Email, Employee Payslip By Email, payslip mail, the mass employee send payslip mail, send payslip batch, mass send payslip mail, employee payslip mail, send payslip mail multiple employees,bulk payslip mail employee',
    'depends': ['hr_payroll_community'],
    'data': [
        'data/template_of_payslip_email.xml',
        'views/dev_payslip_mail.xml',
        'views/dev_payslip_batches_mail.xml',
        'views/salary_rule_empha.xml',
        'wizard/bulk_send_payslips_view.xml',
        'views/config_view.xml'
        ],
    'demo': [],
    'test': [],
    'css': [],
    'qweb': [],
    'js': [],
    'images': ['images/main_screenshot.jpg'],
    'installable': True,
    'application': True,
    'auto_install': False,
    
    # author and support Details =============#
    'author': 'DevIntelle Consulting Service Pvt.Ltd',
    'website': 'http://www.devintellecs.com',    
    'maintainer': 'DevIntelle Consulting Service Pvt.Ltd', 
    'support': 'devintelle@gmail.com',
    'price':9.0,
    'currency':'EUR',
    #'live_test_url':'https://youtu.be/A5kEBboAh_k',
}

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
