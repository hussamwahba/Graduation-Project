Payslip Email:
=========================================================

Go to Setting / apps and search "Payslip / Payslip Email" and Install

And, you are done with installation. Congratulations!
