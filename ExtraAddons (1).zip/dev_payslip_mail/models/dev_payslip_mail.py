# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2015 DevIntelle Consulting Service Pvt.Ltd (<http://www.devintellecs.com>).
#
#    For Module Support : devintelle@gmail.com  or Skype : devintelle
#
##############################################################################

# from _typeshed import FileDescriptor
from odoo import api, models, fields
from odoo.tools.misc import formatLang
import datetime as dt
from calendar import monthrange


class PayrollConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    payslip_email = fields.Char(string='Email to send payslips from')
    leaves_code = fields.Char(string='code of leaves input')

    def set_values(self):
        super(PayrollConfigSettings, self).set_values()
        set_param = self.env['ir.config_parameter'].set_param
        set_param('payslip_email', self.payslip_email)
        set_param('leaves_code', self.leaves_code)

    @api.model
    def get_values(self):
        res = super(PayrollConfigSettings, self).get_values()
        get_param = self.env['ir.config_parameter'].sudo().get_param
        res.update(
            payslip_email=get_param('payslip_email', default=''),
            leaves_code=get_param('leaves_code', default=''),
        )
        return res



class EmphaRule(models.Model):
    _inherit = 'hr.salary.rule'
    empha=fields.Boolean("Emphasize in payslip?",default=False)

class HrPayslip(models.Model):
    _name = 'hr.payslip'
    _inherit = ['hr.payslip', 'mail.thread']

    sent=fields.Boolean(default=False)
    
    def wage(self):
        cur_id=self.env['res.currency'].search([('name', '=', 'USD')], limit=1)
        num=formatLang(self.env, self.contract_id.wage, currency_obj=cur_id)
        return num
    
    def month_work_days(self):
        date = dt.datetime(self.date_from.year,self.date_from.month,1)
        businessdays = 0
        for i in range(1, 32):
            try:
                thisdate = dt.date(date.year, date.month, i)
            except(ValueError):
                break
            if thisdate.weekday() not in [4,5]: # friday = 4, saturday = 5 
                businessdays += 1

        return int(businessdays)


    def days_employed(self):
        sum = 0
        for line in self.worked_days_line_ids:
            sum += line.number_of_days
        return int(sum)

    def days_worked(self):
        return int(self.days_employed()-self.unpaidLeave())

    def unpaidLeave(self):
        for input in self.input_line_ids:
            if input.code==self.env['ir.config_parameter'].sudo().get_param('leaves_code', default='0'):
                if input.amount > 0:
                    return int(input.amount)
                else:
                    return int(0)
            else:
                return int(0)
        return int(0)

    def month_days(self):
        month=int(self.date_to.month)
        year=int(self.date_to.year)
        return monthrange(year,month)[1]

    def payslip_email(self):
        return self.env['ir.config_parameter'].sudo().get_param('payslip_email', default='')

    def send_payslip_email(self):
        self.ensure_one()
        ir_model_data = self.env['ir.model.data']
        try:
            template_id = ir_model_data.get_object_reference(
                'dev_payslip_mail', 'email_template_edi_hr_paysip')[1]
        except ValueError:
            template_id = False
        try:
            compose_form_id = ir_model_data.get_object_reference(
                'mail', 'email_compose_message_wizard_form')[1]
        except ValueError:
            compose_form_id = False
        ctx = {
            'default_model': 'hr.payslip',
            'default_res_id': self.ids[0],
            'default_use_template': bool(template_id),
            'default_template_id': template_id,
            'default_composition_mode': 'comment',
            'mark_so_as_sent': True,
            'force_email': True
        }
        return {
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'mail.compose.message',
            'views': [(compose_form_id, 'form')],
            'view_id': compose_form_id,
            'target': 'new',
            'context': ctx,
        }

    def salary_computation_table(self):
        salary_table = ''
        salary_table += '''<th align="left" style="font-size:12px"  ><strong>Pay-slip Details</strong></th>
        <table style="width:700px;table-layout: fixed">
      <tr>
        <td style="border-top: 1px solid black;"><strong>Increments & Deductions</strong></td>
        <td style="border-top: 1px solid black;"><strong>amount</strong></td>
        <td style="border-top: 1px solid black;"><strong>note</strong></td>
        <td style="border-top: 1px solid black;"><strong></strong></td>
      </tr>'''
        x = 0
        for line in self.line_ids:
            if line.amount!=0 and line.salary_rule_id.appears_on_payslip:

                cur_id=self.env['res.currency'].search([('name', '=', 'USD')], limit=1)
                amount = formatLang(line.env, line.amount, currency_obj=cur_id)
                    
                note=line.note
                if line.note==False:
                    note=""
                
                
                def tr_start():
                    empha = line.salary_rule_id.empha
                    nonlocal x
                    code=""
                    if x == 0:
                        x+=1
                        code+= '<tr style="background-color:#E5E8E8; '
                        if empha:
                            code+='font-weight:bold"'
                        else:
                            code+='"'

                    else:
                        x=0 
                        code+= '<tr'
                        if empha:
                            code+=' style="font-weight:bold"'
                    code+=">"

                    return code

                tr_end = "</tr>"
                def td_startB():
                    if line.salary_rule_id.empha:
                        return '<td style="border-top:0.5px solid black">'
                    else:
                        return "<td>"
                
                td_start ="<td>"
                td_startS ="<td colspan=2>"
                td_end = "</td>"

                salary_table += tr_start() + td_start + line.name + td_end + td_startB() + \
                                amount + td_end + td_startS + \
                                note + td_end + tr_end

        salary_table += '''</table> '''
        self.sent=True
        return salary_table

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
