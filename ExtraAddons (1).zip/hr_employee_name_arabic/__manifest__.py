{
    'sequence':-5,
    'name':'Employee Name In Arabic',
    'author':'Laith Shelleh',
    'depends':['hr_contract'],
    'data':['view.xml'],
}