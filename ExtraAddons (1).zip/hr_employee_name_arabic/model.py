from odoo import api,models,fields

class ContractTransferDetails (models.Model):
    _inherit="hr.employee"

    arabicName=fields.Char("Arabic Name")
