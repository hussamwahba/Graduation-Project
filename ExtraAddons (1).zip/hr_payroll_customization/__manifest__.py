{
	'name': 'Hr Payroll Customization',
	'author': 'Bashir Alsuty', 
	'sequence': -8,
	'depends': ['hr_payroll_account_community'],
	'data': [
		'views/contract_salary_rule.xml',
		],

}