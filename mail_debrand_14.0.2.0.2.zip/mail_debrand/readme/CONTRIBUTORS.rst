* Lois Rilo <lois.rilo@eficent.com>
* Graeme Gellatly <graeme@o4sb.com>
* `Tecnativa <https://www.tecnativa.com>`__:

  * Pedro M. Baeza
  * João Marques
